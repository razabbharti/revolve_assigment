import csv
import os
import json
from datetime import datetime
from datetime import date


customer_file="./input_data/starter/customers.csv"
product_file="./input_data/starter/products.csv"
transaction_files="./input_data/starter/transactions/"
output_file="./output_data/outputs/"


customer=[]
with open(customer_file) as file:
    reader=csv.reader(file)
    fields = next(reader)
    for i in reader:
        if len(i)>0:
            temp={}
            temp["customer_id"]=i[0]
            temp["loyalty_score"]=i[1]
            customer.append(temp)

product=[]
with open(product_file) as file:
    reader=csv.reader(file)
    fields_product = next(reader)
    for i in reader:
        if len(i)>0:
            temp={}
            temp["product_id"]=i[0]
            temp["product_description"]=i[1]
            temp["product_category"]=i[2]
            product.append(temp)

arr = os.listdir(transaction_files)

pre_final=[]
dates=[]
path=transaction_files
for i in arr:
    f=os.listdir(path+'\\'+i)
    dates.append(i[2:])
    with open(path+'\\'+i+'\\'+f[0]) as file:
        reader=csv.reader(file,delimiter="|")
        for j in reader:
            tmp=json.loads(j[0])
            tmp1=tmp.get("customer_id")
            #print(tmp1)
            tmp2=tmp.get("basket")
            #print(tmp2)
            tmp3=tmp.get("date_of_purchase")
            #print(tmp3)
            dic={}
            for k in customer:
                if k.get('customer_id')==tmp1:
                    dic['customer_id']=k.get('customer_id')
                    dic['loyalty_score']=k.get('loyalty_score')
            dic["date_of_purchase"]=tmp3
            #print(dic)
            buck=[]
            for l in tmp2:
                d={}
                for m in product:
                    if l.get('product_id') == m.get('product_id'):
                        d['product_id']=m.get('product_id')
                        d['product_category']=m.get('product_category')
                        buck.append(d)
            #print(buck)
            dic['bucket']=buck
            #print(dic)
            cid=dic
            pre_final.append(cid)

weeks=[]
for i in dates:
    date_time_obj = datetime.strptime(i, '%Y-%m-%d')
    weeks.append(datetime.strftime(date_time_obj,'%W'))

desti_path=output_file

for i in weeks:
    os.makedirs(output_file+"/"+i)

for i in pre_final:
    tmp=(i.get('date_of_purchase'))[:-9]
    tmp2=i
    obj = datetime.strptime(tmp, '%Y-%m-%d')
    folder_name=(datetime.strftime(obj,'%W'))
    json_object = json.dumps(tmp2)
    with open(desti_path+folder_name+"\\data.json","a",encoding="utf-8",newline="\n") as file:
        file.write(json_object+"\n")
    
final_folders=os.listdir(desti_path)
for i in final_folders:
    final=[]
    n_fol=i
    w=[]
    c_id=[]
    with open(desti_path+i+"\\data.json") as file:
        reader=csv.reader(file,delimiter="|")
        for i in reader:
            w.append((i[0]))
            tmp=json.loads((i[0]))
            tmp2=(tmp.get('customer_id'))
            c_id.append(tmp2)
    unique_c_id=list(set(c_id))
    repeated_c_id=[]
    el=[]
    for i in unique_c_id:
        if (c_id.count(i)) > 1:
            repeated_c_id.append(i)
        else:
            el.append(i)
    for i in repeated_c_id:
        b={}
        b['customer_id']=""
        b['loyalty_score']=""
        b['products']=[]
        b['purchase_count']=""
        for j in w:
            tmp=json.loads(j)
            if i == tmp.get('customer_id'):
                b['customer_id']=i
                b['loyalty_score']=tmp.get('loyalty_score')
                b['products']=(b.get('products'))+(tmp.get('bucket'))
                b['purchase_count']=len(b.get('products'))
        final.append(b)
    for i in el:
        c={}
        c['customer_id']=""
        c['loyalty_score']=""
        c['products']=[]
        c['purchase_count']=""
        for j in w:
            tmp=json.loads(j)
            if i == tmp.get('customer_id'):
                c['customer_id']=i
                c['loyalty_score']=tmp.get('loyalty_score')
                c['products']=(c.get('products'))+(tmp.get('bucket'))
                c['purchase_count']=len(c.get('products'))
        final.append(c)
    with open(desti_path+n_fol+"\\data.json","w",encoding="utf-8",newline="") as out:
        for x in final:
            json_object = json.dumps(x)
            out.write(json_object+"\n")
